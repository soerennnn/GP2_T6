#define F_CPU 16000000

#define MISO PB3// connected to SDI on LIS3DH
#define MOSI PB2// connected to SDO on LIS3DH
#define SCK PB1  // connected to SCK on LIS3DH
#define CS PB0   // connected to CS on LIS3DH
#define RW 7 // Position of R/W bit
#define MS 6 // Position of M/S bit

#include <avr/io.h>
#include <util/delay.h>
#include <UART.h>
#include <SPI.h>
#include <LIS3DH.h>






int main(void) {
    //Initialisieren Sie die UART-Schnittstelle mit einer Baudrate von 115200 Baud.
    UART0_INIT(8);

    // SPI Initialisierung
    SPI_MasterInit();

    // Initialisieren Sie den Beschleunigungssensor mit dem Befehl:
    SPI_LIS3DH_INIT();

    DDRB |= (1 << CS);
    // Initialisieren Sie den CS-Pin mit einem HIGH-Pegel
    PORTB |= (1 << CS); 

    // Legen Sie drei Variablen x, y und z vom Typ int16_t an
    uint16_t x;
    uint16_t y;
    uint16_t z;


    

    while(1) {


      //  Lesen Sie die drei Achsen des Sensors mit den Befehlen:
        //x = LIS3DH_getX();

      PORTB &= ~(1 << CS);                              // CS auf Low-Pegel
      SPI_MasterTransmit(0x28 | (1 << RW) | (1 << MS)); /* Registeradresse X-Achse LOW Byte Lesen Multiread */
      SPI_MasterReceive();                              // Empfangen (0x00 dummy wird gesendet)
      x = SPDR;                                         // Speichern LowByte in X
      SPI_MasterReceive();                              // Empfangen (0x00 dummy wird gesendet)
      x |= (SPDR << 8);                                 // HIGH Byte Register um acht Bit // shiften und in X speichern
      PORTB |= (1 << CS);                               // CS auf High-pegel

      // Geben Sie die drei Achsen über die serielle Schnittstelle aus
      // Hinweis: Nutzen Sie für x, y und z die UART0_send_ascii() Funktion und senden Sie dazwischen ein Leerzeichen. Senden sie anschließend die 
      // Werte 0x0D und 0x0A, um einen Zeilenumbruch zu bewirken.
      // Schließen Sie den Beschleunigungssensor wie aus dem letzten Termin bekannt an den Arduino an (siehe Tabelle) und kontrollieren Sie den 
      // Kurvenverlauf im seriellen Plotter der Arduino IDE
      UART0_send_ascii(x + '0');
      UART0_send_ascii(' '); // Leerzeichen
      UART0_send(0x0D); // Carriage Return
      UART0_send(0x0A); // Line Feed
      _delay_ms(100);


    }
}
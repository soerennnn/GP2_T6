/*******************************************************************************
 ***                                                                         ***
 *** filename:   UART.h                                                      ***
 ***                                                                         ***
 *** project:    Grundpraktikum II                                           ***
 ***                                                                         ***
 *** created on: 2020-03-20                                                  ***
 ***                                                                         ***
 *** created by: Lukas Kroll                                                 ***
 ***             FH Dortmund                                                 ***
 ***             Labore fuer Informationstechnik                             ***
 ***             lukas.kroll@fh-dortmund.de                                  ***
 ***                                                                         ***
 ***                                                                         ***
 *** version:    1.0.0                                                       ***
 ***                                                                         ***
 *** updated on:                                                             ***
 ***                                                                         ***
 *** info:       UART Bibliothek for use with Atmel Atmega 2560 only         ***
 ***             Atmega 2560 has four UART interfaces                        ***
 ***             UART0 is accessable via USB connection                      ***
 ***                                                                         ***
 ***                                                                         ***
 ******************************************************************************/

#ifndef UART_H_
#define UART_H_
    #ifndef F_CPU 
        #define F_CPU 16000000UL
    #endif     
    #if defined(__AVR_ATmega2560__)

        /************************************************************************/
        /*				           UART 0	                            */
        /************************************************************************/

        void UART0_INIT(uint16_t ubrr);				// Initialisierung  der UART Schnittstelle "0"
                                                        // 8bit, 1 Stopbit, Geschw. = baud
        void UART0_send(unsigned char data);			// Sendet ein unsigned char ¸ber die USART Schnittstelle "0"

        unsigned char UART0_receive(void);				// Gibt ein empfangenes Zeichen als unsigned char zur¸ck 

        uint8_t UART0_msgRCV();						// Rueckgabewert:	0 wenn keine Nachrichtempfangen wurde 
                                                        //					1 wenn eine Nachricht empfangen wurde
        void UART0_send_ascii(uint32_t toprint);
        /************************************************************************/
        /*				           UART 1	                            */
        /************************************************************************/



        void UART1_INIT(uint16_t ubrr);				// Initialisierung  der UART Schnittstelle "1"
                                                        // 8bit, 1 Stopbit, Geschw. = baud
        void UART1_send(unsigned char ubrr);

        unsigned char UART1_receive(void);

        uint8_t UART1_msgRCV();						// R¸ckgabewert:	0 wenn keine Nachrichtempfangen wurde
                                                        //					1 wenn eine Nachricht empfangen wurde

        /************************************************************************/
        /*				           UART 2	                            */
        /************************************************************************/



        void UART2_INIT(uint16_t ubrr);				// Initialisierung  der UART Schnittstelle "2"
                                                        // 8bit, 1 Stopbit, Geschw. = baud
        void UART2_send(unsigned char ubrr);

        unsigned char UART2_receive(void);

        uint8_t UART2_msgRCV();						// R¸ckgabewert:	0 wenn keine Nachrichtempfangen wurde
                                                        //					1 wenn eine Nachricht empfangen wurde


        /************************************************************************/
        /*				           UART 3	                            */
        /************************************************************************/



        void UART3_INIT(uint16_t ubrr);				// Initialisierung  der UART Schnittstelle "3"
                                                        // 8bit, 1 Stopbit, Geschw. = baud
        void UART3_send(unsigned char ubrr);

        unsigned char UART3_receive(void);

        uint8_t UART3_msgRCV();						// R¸ckgabewert:	0 wenn keine Nachrichtempfangen wurde
                                                        //					1 wenn eine Nachricht empfangen wurde
    #endif //defined (__AVR_ATmega2560__)
#endif /* UART_H_ */


/*
 * SPI.c
 *
 * Created: 08.05.2018 15:02:26
 *  Author: Kroll
 */ 
#include <avr/io.h>
#include "SPI.h"



/************************************************************************/
/*				           SPI FUNCTIONS	                            */
/************************************************************************/

void SPI_MasterInit(void)
{
	/* Write  SPI config to DDRB MOSI SCK CS --> Output*/
	DDRB |= (1<<MOSI)|(1<<SCK)|(1<<CS);
	/* Enable SPI, Master,  SPR0 --> fosc/16, set SPI Mode 3 --> CPOL = 1 and CPHA = 1 */
	SPCR |= (1<<SPE)|(1<<MSTR)|(1<<SPR0)|(1<<SPR1)|(1<<CPOL)|(1<<CPHA);
}

void SPI_MasterTransmit(char data)
{
	
	/* Start transmission */
	SPDR = data;							// put cData to out
	/* Wait for transmission complete */
	while
	(!(SPSR & (1<<SPIF)));					// SPIF : SPI Interupt Flag
	
}

uint8_t SPI_MasterReceive(void)
{
	/*ein "leere" Byte wird gesendet, damit die Daten aus dem Slavebuffer geschoben werden*/
	SPI_MasterTransmit(0x00);
	/* R�ckgabewert = SPI register*/
	return SPDR;
}

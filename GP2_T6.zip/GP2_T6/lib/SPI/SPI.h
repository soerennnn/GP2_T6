/*
 * SPI.h
 *
 * Created: 08.05.2018 15:02:36
 *  Author: Kroll
 */ 


#ifndef SPI_H_
#define SPI_H_

/************************************************************************/
/*							PIN CONFIG SPI								*/
/************************************************************************/

#define MISO	PB3		//Pin 50		--> SDA (SDI)	on LIS3DH
#define MOSI	PB2		//Pin 51		--> SDO			on LIS3DH
#define SCK		PB1		//Pin 52		--> SCL			on LIS3DH
#define CS		PB0		//Pin 53		--> CS			on LIS3DH

void SPI_MasterInit(void);
void SPI_MasterTransmit(char data);
uint8_t SPI_MasterReceive(void);




#endif /* SPI_H_ */
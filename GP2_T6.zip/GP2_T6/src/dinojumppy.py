import serial
import serial.tools.list_ports_windows
import pyautogui

#Serielle Verbundung herstellen
ports = list(serial.tools.list_ports_windows.comports())
if len(ports) == 0:
    print("Kein serieller Port gefunden!")
    exit()
for i, port in enumerate(ports):
    print("{}.{}:{}".format(i+1,port.device,port.description))
port_idx = int(input("Wählen Sie einen Port aus der obigen Liste aus(Geben Sie die Nummer ein ): "))
if port_idx <1 or port_idx > len(ports):
    print("Ungültige Auswahl!")
    exit()
ser = serial.Serial(ports[port_idx-1].device, 115200, timeout=1)
print("Verbindung hergestellt. Baudrate = 115200 bit/s. Virtueller Tastendruck bei jedem emfpangenen 'T' (ASCII).")

while True:
    #Nachricht verfügbar?
    if (ser.in_waiting > 0):
        #Zeichen empfangen
        data = ser.read().decode().strip()
        
        #Wenn "T" empfangen wurde, Leertaste simulieren 
        if data == 'T':
            pyautogui.press('space') 
#define F_CPU 16000000

#define MISO PB3// connected to SDI on LIS3DH
#define MOSI PB2// connected to SDO on LIS3DH
#define SCK PB1  // connected to SCK on LIS3DH
#define CS PB0   // connected to CS on LIS3DH

#include <avr/io.h>
#include <util/delay.h>
#include <UART.h>
#include "SPI.h"





int main(void) {
    //Initialisieren Sie die UART-Schnittstelle mit einer Baudrate von 115200 Baud.
    UART0_INIT(8);

    // SPI Initialisierung
    SPI_MasterInit();

    // PIN 7 als Eingang
    DDRH &= ~(1<<PH4);

    // T Variable zuweisen
    char Ausgabe = 84;

    

    while(1) {
        if(PINH & (1<<PH4)) {
           //T ausgeben
           UART0_send(Ausgabe);
           _delay_ms(200);
        }
    }
}